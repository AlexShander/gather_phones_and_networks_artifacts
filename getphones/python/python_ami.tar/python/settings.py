connection = {
'address': '127.0.0.1',
'port': 5038
}

login = {
'username': 'admin',
'secret': 'password'
}
